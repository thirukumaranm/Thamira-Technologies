import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import LearningDomains from './components/domains/LearningDomains';
import Program from './components/Program';
import ProgramDetails from './components/program/ProgramDetails';
import Curriculum from './components/program/Curriculum';
import Contact from './components/Contact';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main>
        <Hero />
        <About />
        <LearningDomains />
        <Program />
        <ProgramDetails />
        <Curriculum />
        <Contact />
      </main>
      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p>&copy; {new Date().getFullYear()} Thamira Technologies. All rights reserved.</p>
          <p className="mt-2 text-sm text-gray-400">
            Visit our main website: <a href="https://thamiratech.in" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300">thamiratech.in</a>
          </p>
        </div>
      </footer>
    </div>
  );
}