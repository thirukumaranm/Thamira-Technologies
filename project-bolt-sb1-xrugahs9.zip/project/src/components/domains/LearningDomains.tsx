import React from 'react';
import DomainCard from './DomainCard';
import { Code2, Globe, Database, Cloud, Server, Shield } from 'lucide-react';

const domains = [
  {
    icon: Code2,
    title: 'Frontend Development',
    description: 'Master modern frameworks like React.js, Next.js, and responsive design principles.',
    skills: ['HTML5/CSS3', 'JavaScript/TypeScript', 'React.js', 'Next.js', 'Tailwind CSS']
  },
  {
    icon: Server,
    title: 'Backend Development',
    description: 'Build robust server-side applications and RESTful APIs.',
    skills: ['Node.js', 'Express.js', 'Python', 'Java', 'API Development']
  },
  {
    icon: Database,
    title: 'Database Management',
    description: 'Learn both SQL and NoSQL database design and optimization.',
    skills: ['PostgreSQL', 'MongoDB', 'Redis', 'Database Design', 'Query Optimization']
  },
  {
    icon: Cloud,
    title: 'Cloud Technologies',
    description: 'Deploy and manage applications on cloud platforms.',
    skills: ['AWS', 'Docker', 'Kubernetes', 'CI/CD', 'Microservices']
  },
  {
    icon: Shield,
    title: 'Security Practices',
    description: 'Implement secure coding practices and authentication systems.',
    skills: ['OAuth', 'JWT', 'Security Best Practices', 'Data Protection', 'Access Control']
  },
  {
    icon: Globe,
    title: 'Web Services',
    description: 'Design and integrate modern web services and APIs.',
    skills: ['REST APIs', 'GraphQL', 'WebSockets', 'Service Integration', 'API Security']
  }
];

export default function LearningDomains() {
  return (
    <div id="domains" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">Learning Domains</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Comprehensive Full Stack Curriculum
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
            Our training program covers all essential aspects of modern web development
          </p>
        </div>
        <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {domains.map((domain, index) => (
            <DomainCard key={index} {...domain} />
          ))}
        </div>
      </div>
    </div>
  );
}