import React from 'react';
import { LucideIcon } from 'lucide-react';

interface DomainCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  skills: string[];
}

export default function DomainCard({ icon: Icon, title, description, skills }: DomainCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <div className="p-6">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <Icon className="h-8 w-8 text-blue-600" />
          </div>
          <div className="ml-4">
            <h3 className="text-lg font-medium text-gray-900">{title}</h3>
          </div>
        </div>
        <p className="mt-4 text-base text-gray-500">{description}</p>
        <div className="mt-4">
          <h4 className="text-sm font-medium text-gray-900">Key Skills:</h4>
          <div className="mt-2 flex flex-wrap gap-2">
            {skills.map((skill, index) => (
              <span
                key={index}
                className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}