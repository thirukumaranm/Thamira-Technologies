import React from 'react';
import { Calendar, Clock, Users, Award } from 'lucide-react';

const details = [
  {
    icon: Calendar,
    title: 'Program Duration',
    description: '12 months of intensive training and hands-on experience'
  },
  {
    icon: Clock,
    title: 'Learning Schedule',
    description: '40 hours per week with flexible learning paths'
  },
  {
    icon: Users,
    title: 'Batch Size',
    description: 'Limited to 20 students for personalized attention'
  },
  {
    icon: Award,
    title: 'Certification',
    description: 'Industry-recognized certification upon completion'
  }
];

export default function ProgramDetails() {
  return (
    <div className="bg-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          {details.map((detail, index) => {
            const Icon = detail.icon;
            return (
              <div key={index} className="flex flex-col items-center text-center">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-600 text-white">
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-gray-900">{detail.title}</h3>
                <p className="mt-2 text-base text-gray-500">{detail.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}