import React from 'react';

const modules = [
  {
    phase: 'Phase 1: Foundation',
    duration: '3 months',
    topics: [
      'HTML5, CSS3, and JavaScript fundamentals',
      'Version control with Git',
      'Basic algorithms and data structures',
      'Introduction to React.js'
    ]
  },
  {
    phase: 'Phase 2: Advanced Frontend',
    duration: '3 months',
    topics: [
      'React.js and Next.js deep dive',
      'State management (Redux, Context API)',
      'UI/UX principles',
      'Performance optimization'
    ]
  },
  {
    phase: 'Phase 3: Backend Development',
    duration: '3 months',
    topics: [
      'Node.js and Express.js',
      'Database design and management',
      'API development',
      'Authentication and authorization'
    ]
  },
  {
    phase: 'Phase 4: Production & Deployment',
    duration: '3 months',
    topics: [
      'Cloud deployment (AWS)',
      'CI/CD pipelines',
      'Security best practices',
      'Real-world project implementation'
    ]
  }
];

export default function Curriculum() {
  return (
    <div className="bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h3 className="text-2xl font-bold text-gray-900 mb-8">Program Curriculum</h3>
        <div className="space-y-8">
          {modules.map((module, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md p-6">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-lg font-semibold text-blue-600">{module.phase}</h4>
                <span className="text-sm text-gray-500">{module.duration}</span>
              </div>
              <ul className="space-y-2">
                {module.topics.map((topic, topicIndex) => (
                  <li key={topicIndex} className="text-gray-600 flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
                    {topic}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}