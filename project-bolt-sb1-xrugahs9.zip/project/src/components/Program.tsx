import React from 'react';
import { CheckCircle } from 'lucide-react';

export default function Program() {
  const features = [
    'Hands-on experience with real projects',
    'Mentoring from senior developers',
    'Full stack development training',
    'Modern technology stack',
    'Project management skills',
    'Career guidance and support'
  ];

  return (
    <div id="program" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">Training Program</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            One Year of Intensive Learning
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Our comprehensive program combines theoretical knowledge with practical experience.
          </p>
        </div>

        <div className="mt-16">
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="px-6 py-8 sm:p-10">
              <div className="space-y-6">
                {features.map((feature, index) => (
                  <div key={index} className="flex">
                    <CheckCircle className="flex-shrink-0 h-6 w-6 text-green-500" />
                    <p className="ml-3 text-base text-gray-700">{feature}</p>
                  </div>
                ))}
              </div>
              <div className="mt-8">
                <a href="#contact" className="w-full flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                  Apply Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}